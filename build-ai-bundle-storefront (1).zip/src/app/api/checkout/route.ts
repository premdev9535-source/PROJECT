import { NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { db } from '@/db';
import { orders } from '@/db/schema';
import { v4 as uuidv4 } from 'uuid';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_placeholder',
  key_secret: process.env.RAZORPAY_KEY_SECRET || 'secret_placeholder',
});

export async function POST(req: Request) {
  try {
    const { email } = await req.json();

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    const amount = 299 * 100; // ₹299 in paise

    const options = {
      amount: amount,
      currency: 'INR',
      receipt: uuidv4(),
    };

    const order = await razorpay.orders.create(options);

    // Save order to DB as pending
    await db.insert(orders).values({
      id: uuidv4(),
      email: email,
      amount: amount,
      status: 'pending',
      razorpayOrderId: order.id,
    });

    return NextResponse.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
    });
  } catch (error: any) {
    console.error('Razorpay Order Error:', error);
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 });
  }
}
