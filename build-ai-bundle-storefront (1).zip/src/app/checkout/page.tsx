"use client";

import React, { useState } from 'react';
import { Loader2, ShieldCheck, CreditCard } from 'lucide-react';

export default function CheckoutPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID, // Must be provided by user
        amount: data.amount,
        currency: data.currency,
        name: 'AI Growth Bundle Kit',
        description: 'Instant access to AI Growth Bundle',
        order_id: data.orderId,
        handler: async function (response: any) {
          // Verify payment on server
          const verifyRes = await fetch('/api/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_signature: response.razorpay_signature,
            }),
          });

          if (verifyRes.ok) {
            window.location.href = `/success?orderId=${data.orderId}`;
          } else {
            alert('Payment verification failed. Please contact support.');
          }
        },
        prefill: {
          email: email,
        },
        theme: {
          color: '#4f46e5',
        },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <CreditCard size={32} />
          </div>
          <h1 className="text-2xl font-bold mb-2">Complete Your Purchase</h1>
          <p className="text-slate-500">You're one step away from scaling your growth.</p>
        </div>

        <div className="bg-slate-50 rounded-2xl p-4 mb-8 flex justify-between items-center border border-slate-100">
          <div>
            <div className="text-sm text-slate-500 font-medium">AI Growth Bundle Kit</div>
            <div className="text-slate-400 line-through text-xs">₹599</div>
          </div>
          <div className="text-2xl font-bold text-indigo-600">₹299</div>
        </div>

        <form onSubmit={handlePayment} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            />
            <p className="text-xs text-slate-400 mt-2">We'll send your digital bundle to this email.</p>
          </div>

          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin" /> Processing...
              </>
            ) : (
              'Pay Now ₹299'
            )}
          </button>
        </form>

        <div className="mt-8 flex items-center justify-center gap-2 text-slate-400 text-xs">
          <ShieldCheck size={14} />
          <span>Secure 256-bit SSL encrypted payment</span>
        </div>
      </div>
    </div>
  );
}
