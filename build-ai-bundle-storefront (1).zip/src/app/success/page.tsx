"use client";

import React, { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { CheckCircle, Download, ArrowLeft, ShieldCheck } from 'lucide-react';
import Link from 'next/link';

function SuccessContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get('orderId');
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function verifyOrder() {
      if (!orderId) {
        setLoading(false);
        return;
      }
      try {
        const res = await fetch(`/api/verify-order?orderId=${orderId}`);
        if (res.ok) {
          setVerified(true);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    verifyOrder();
  }, [orderId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!verified) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl text-center">
          <h1 className="text-2xl font-bold mb-4">Unable to verify purchase</h1>
          <p className="text-slate-600 mb-6">We couldn't find a completed payment for this order. Please check your email or contact support.</p>
          <Link href="/" className="text-indigo-600 font-semibold flex items-center justify-center gap-2">
            <ArrowLeft size={18} /> Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl border border-slate-100 p-8 md:p-12 text-center">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle size={48} />
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold mb-4">Payment Successful! 🎉</h1>
        <p className="text-slate-600 text-lg mb-10">
          Your AI Growth Bundle Kit is ready for download. Start scaling your content and growth today.
        </p>

        <div className="bg-indigo-50 rounded-3xl p-8 border-2 border-dashed border-indigo-200 mb-10">
          <h3 className="text-indigo-900 font-bold text-xl mb-4">Your Digital Bundle</h3>
          <p className="text-indigo-700 mb-6 text-sm">Includes: Prompts, Strategy Guide, Growth Checklist, and Tool Directory.</p>
          <a 
            href={`/api/download?orderId=${orderId}`} 
            className="inline-flex items-center justify-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all w-full sm:w-auto"
          >
            <Download size={20} /> Download Bundle (.txt)
          </a>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-slate-400 text-sm">
          <div className="flex items-center gap-2">
            <ShieldCheck size={16} />
            <span>Secure Delivery</span>
          </div>
          <div className="hidden sm:block">|</div>
          <Link href="/" className="hover:text-indigo-600 transition-colors">Return to Homepage</Link>
        </div>
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600"></div>
      </div>
    }>
      <SuccessContent />
    </Suspense>
  );
}
