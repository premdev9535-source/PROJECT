import React from 'react';
import Link from 'next/link';
import { CheckCircle, Rocket, Zap, ShieldCheck, Star, ArrowRight } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="py-6 px-4 max-w-7xl mx-auto flex justify-between items-center">
        <div className="text-2xl font-bold tracking-tight text-indigo-600">AI Growth Kit</div>
        <Link 
          href="/checkout" 
          className="bg-indigo-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
        >
          Get it Now
        </Link>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 max-w-5xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 px-4 py-1 rounded-full text-sm font-medium mb-6">
          <Zap size={16} />
          <span>Limited Time Offer for India 🇮🇳</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-tight">
          Scale Your Growth with the <span className="text-indigo-600">AI Bundle Kit</span>
        </h1>
        <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
          Stop guessing and start growing. Get the exact AI prompts, strategies, and checklists used by top creators to 10x their output and engagement.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <Link 
            href="/checkout" 
            className="w-full sm:w-auto bg-indigo-600 text-white px-10 py-4 rounded-2xl text-xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 flex items-center justify-center gap-2 group"
          >
            Get the Bundle Now <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <div className="text-center sm:text-left">
            <span className="text-slate-400 line-through text-lg">₹599</span>
            <span className="text-3xl font-bold ml-2">₹299</span>
            <p className="text-sm text-slate-500 font-medium">One-time payment</p>
          </div>
        </div>
        <div className="mt-8 flex items-center justify-center gap-4 text-slate-500 text-sm">
          <div className="flex items-center gap-1"><ShieldCheck size={16} /> Secure Payment</div>
          <div className="flex items-center gap-1"><CheckCircle size={16} /> Instant Delivery</div>
        </div>
      </section>

      {/* What's Inside */}
      <section className="py-20 bg-white px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Everything you need to dominate the AI era</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">A complete toolkit designed for freelancers, marketers, and creators who want to save 20+ hours a week.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "50+ High-Conv Prompts",
                desc: "Copy-paste prompts for LinkedIn, Twitter, and Instagram that actually convert followers into customers.",
                icon: <Zap className="text-yellow-500" />,
                color: "bg-yellow-50"
              },
              {
                title: "AI Strategy Guide",
                desc: "A step-by-step blueprint on how to integrate AI into your daily content workflow.",
                icon: <Rocket className="text-blue-500" />,
                color: "bg-blue-50"
              },
              {
                title: "Growth Checklist",
                desc: "The ultimate daily and weekly checklist to ensure your AI-driven growth stays on track.",
                icon: <CheckCircle className="text-green-500" />,
                color: "bg-green-50"
              },
              {
                title: "AI Tool Directory",
                desc: "A curated list of 100+ AI tools (beyond ChatGPT) to automate your entire business.",
                icon: <Star className="text-purple-500" />,
                color: "bg-purple-50"
              },
            ].map((item, i) => (
              <div key={i} className="p-8 rounded-3xl border border-slate-100 hover:border-indigo-200 transition-all hover:shadow-lg group">
                <div className={`w-12 h-12 ${item.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 px-4 bg-indigo-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-12">Joined by 500+ Indian Creators</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Arjun Mehta", role: "Freelance Designer", text: "The prompts alone are worth 10x the price. My LinkedIn engagement tripled in 2 weeks!" },
              { name: "Sneha Kapoor", role: "Content Marketer", text: "Finally a bundle that understands the Indian market. Highly recommended for beginners." },
              { name: "Rahul Sharma", role: "Solopreneur", text: "The AI Tool Directory is a goldmine. Saved me hours of researching tools." },
            ].map((t, i) => (
              <div key={i} className="bg-indigo-500/50 p-6 rounded-2xl text-left backdrop-blur-sm border border-indigo-400">
                <div className="flex gap-1 text-yellow-400 mb-3">
                  {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                </div>
                <p className="italic mb-4 text-indigo-50">"{t.text}"</p>
                <div className="font-bold">{t.name}</div>
                <div className="text-sm text-indigo-200">{t.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 max-w-3xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
        <div className="space-y-6">
          {[
            { q: "How will I receive the kit?", a: "Immediately after payment, you'll be redirected to a download page, and we'll send a copy to your email." },
            { q: "Is this a subscription?", a: "No, it's a one-time payment for lifetime access to the current bundle and all future updates." },
            { q: "Will this work for my niche?", a: "Yes, the prompts are designed to be versatile across any business, service, or creative niche." },
            { q: "Is payment secure?", a: "Absolutely. We use Razorpay, India's leading payment gateway, ensuring your data is encrypted and safe." },
          ].map((faq, i) => (
            <div key={i} className="p-6 bg-white rounded-2xl border border-slate-200">
              <h3 className="font-bold text-lg mb-2">{faq.q}</h3>
              <p className="text-slate-600">{faq.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 px-4 text-center bg-slate-100">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold mb-6">Ready to 10x your growth?</h2>
          <p className="text-xl text-slate-600 mb-10">Grab the AI Growth Bundle Kit today for just ₹299 before the price goes back to ₹599.</p>
          <Link 
            href="/checkout" 
            className="inline-flex items-center justify-center bg-indigo-600 text-white px-12 py-5 rounded-2xl text-2xl font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 gap-2 group"
          >
            Get Instant Access <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <p className="mt-6 text-slate-500 font-medium flex items-center justify-center gap-2">
            <ShieldCheck size={18} /> 100% Secure Payment via Razorpay
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 text-center text-slate-400 text-sm border-t border-slate-200">
        <p>© {new Date().getFullYear()} AI Growth Kit. All rights reserved.</p>
        <p className="mt-2">Made with ❤️ for the Indian Creator Community</p>
      </footer>
    </div>
  );
}
