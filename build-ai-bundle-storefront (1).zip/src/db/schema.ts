import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";

export const orders = pgTable("orders", {
  id: text("id").primaryKey(),
  email: text("email").notNull(),
  amount: integer("amount").notNull(), // in paise (for Razorpay)
  status: text("status").notNull().default("pending"), // 'pending' | 'completed'
  razorpayOrderId: text("razorpay_order_id"),
  razorpayPaymentId: text("razorpay_payment_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});